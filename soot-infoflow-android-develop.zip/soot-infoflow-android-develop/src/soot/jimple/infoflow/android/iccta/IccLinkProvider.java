package soot.jimple.infoflow.android.iccta;

import java.util.List;

public interface IccLinkProvider 
{  
    public List<IccLink> getIccLinks();
}
